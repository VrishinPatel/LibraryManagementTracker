import sqlite3
from datetime import datetime

def create_tables():
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Create books table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS books (
            id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            author TEXT NOT NULL,
            available INTEGER NOT NULL DEFAULT 1
        )
    ''')

    # Create members table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS members (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL
        )
    ''')

    # Create transactions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY,
            book_id INTEGER,
            member_id INTEGER,
            type TEXT NOT NULL,
            date TEXT NOT NULL,
            FOREIGN KEY (book_id) REFERENCES books (id),
            FOREIGN KEY (member_id) REFERENCES members (id)
        )
    ''')

    conn.commit()
    conn.close()

def add_book(title, author):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('INSERT INTO books (title, author) VALUES (?, ?)', (title, author))

    conn.commit()
    conn.close()

def add_member(name, email):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('INSERT INTO members (name, email) VALUES (?, ?)', (name, email))

    conn.commit()
    conn.close()

def borrow_book(book_id, member_id):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Check if the book is available
    cursor.execute('SELECT available FROM books WHERE id = ?', (book_id,))
    available = cursor.fetchone()[0]

    if available:
        # Mark the book as not available
        cursor.execute('UPDATE books SET available = 0 WHERE id = ?', (book_id,))
        # Add transaction record
        cursor.execute('INSERT INTO transactions (book_id, member_id, type, date) VALUES (?, ?, ?, ?)', 
                       (book_id, member_id, 'borrow', datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        conn.commit()
        print("Book borrowed successfully!")
    else:
        print("Book is not available.")

    conn.close()

def return_book(book_id, member_id):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    # Mark the book as available
    cursor.execute('UPDATE books SET available = 1 WHERE id = ?', (book_id,))
    # Add transaction record
    cursor.execute('INSERT INTO transactions (book_id, member_id, type, date) VALUES (?, ?, ?, ?)', 
                   (book_id, member_id, 'return', datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    conn.commit()
    conn.close()
    print("Book returned successfully!")

def view_books():
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM books')
    books = cursor.fetchall()

    for book in books:
        print(book)

    conn.close()

def view_members():
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM members')
    members = cursor.fetchall()

    for member in members:
        print(member)

    conn.close()

def main():
    create_tables()
    
    while True:
        print("\nLibrary Management System")
        print("1. Add Book")
        print("2. Add Member")
        print("3. Borrow Book")
        print("4. Return Book")
        print("5. View Books")
        print("6. View Members")
        print("7. Exit")

        choice = input("Enter choice: ")

        if choice == '1':
            title = input("Enter book title: ")
            author = input("Enter book author: ")
            add_book(title, author)
        elif choice == '2':
            name = input("Enter member name: ")
            email = input("Enter member email: ")
            add_member(name, email)
        elif choice == '3':
            book_id = int(input("Enter book ID: "))
            member_id = int(input("Enter member ID: "))
            borrow_book(book_id, member_id)
        elif choice == '4':
            book_id = int(input("Enter book ID: "))
            member_id = int(input("Enter member ID: "))
            return_book(book_id, member_id)
        elif choice == '5':
            view_books()
        elif choice == '6':
            view_members()
        elif choice == '7':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
